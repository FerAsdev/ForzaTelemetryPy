# main.py
import sys
import os
import asyncio
import threading
import time
from PyQt5.QtWidgets import (
    QApplication, QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QTextEdit, QLabel
)
from udp_receiver import UdpReceiver
from reference_data_repository import ReferenceDataRepository

# Clase que ejecuta un event loop de asyncio en un hilo separado
class AsyncRunner(threading.Thread):
    def __init__(self):
        super().__init__()
        self.loop = asyncio.new_event_loop()

    def run(self):
        asyncio.set_event_loop(self.loop)
        self.loop.run_forever()

    def stop(self):
        self.loop.call_soon_threadsafe(self.loop.stop)

# Ventana de la GUI
class TelemetryGUI(QWidget):
    def __init__(self, receiver, async_runner):
        super().__init__()
        self.receiver = receiver
        self.async_runner = async_runner
        self.init_ui()

    def init_ui(self):
        self.setWindowTitle("Forza Telemetry GUI")
        layout = QVBoxLayout()

        # Etiqueta de título
        self.title_label = QLabel("Forza Telemetry")
        layout.addWidget(self.title_label)

        # Layout de botones
        btn_layout = QHBoxLayout()
        self.btn_race = QPushButton("Race")
        self.btn_race.clicked.connect(self.start_race)
        btn_layout.addWidget(self.btn_race)

        self.btn_practice = QPushButton("Practice")
        self.btn_practice.clicked.connect(self.start_practice)
        btn_layout.addWidget(self.btn_practice)

        self.btn_stop = QPushButton("Stop")
        self.btn_stop.clicked.connect(self.stop_receiver)
        btn_layout.addWidget(self.btn_stop)

        self.btn_exit = QPushButton("Exit")
        self.btn_exit.clicked.connect(self.exit_app)
        btn_layout.addWidget(self.btn_exit)
        layout.addLayout(btn_layout)

        # Área de log para ver mensajes
        self.log = QTextEdit()
        self.log.setReadOnly(True)
        layout.addWidget(self.log)

        self.setLayout(layout)

    def log_message(self, msg):
        self.log.append(f"{time.strftime('%H:%M:%S')} - {msg}")

    def start_race(self):
        if not self.receiver.is_listening:
            # Programamos start_listening en el event loop del AsyncRunner
            self.async_runner.loop.call_soon_threadsafe(self.receiver.start_listening, True)
            self.log_message("Race mode started")
        else:
            self.log_message("Receiver already running")

    def start_practice(self):
        if not self.receiver.is_listening:
            self.async_runner.loop.call_soon_threadsafe(self.receiver.start_listening, False)
            self.log_message("Practice mode started")
        else:
            self.log_message("Receiver already running")

    def stop_receiver(self):
        if self.receiver.is_listening:
            self.async_runner.loop.call_soon_threadsafe(self.receiver.stop_listening)
            self.log_message("Receiver stopped")
        else:
            self.log_message("Receiver is not running")

    def exit_app(self):
        self.stop_receiver()
        self.async_runner.stop()
        QApplication.instance().quit()

def main():
    app = QApplication(sys.argv)

    # Configuración de la base de datos y repositorios
    base_dir = os.path.dirname(os.path.abspath(__file__))
    db_path = os.path.join(base_dir, "Data", "referenceData.db")
    os.makedirs(os.path.join(base_dir, "Data"), exist_ok=True)
    car_csv_path = os.path.join(base_dir, "RepositoryCSV", "CarOrdinal.csv")
    track_csv_path = os.path.join(base_dir, "RepositoryCSV", "TrackOrdinal.csv")
    ReferenceDataRepository.ensure_database_and_populate(db_path, car_csv_path, track_csv_path)
    car_names = ReferenceDataRepository.load_car_names(db_path)
    track_names = ReferenceDataRepository.load_track_names(db_path)

    # Crear el UdpReceiver
    receiver = UdpReceiver(car_names, track_names)

    # Iniciar el AsyncRunner en un hilo separado para el event loop de asyncio
    async_runner = AsyncRunner()
    async_runner.start()

    # Crear y mostrar la GUI
    gui = TelemetryGUI(receiver, async_runner)
    gui.resize(600, 400)
    gui.show()
    sys.exit(app.exec_())

if __name__ == "__main__":
    main()
