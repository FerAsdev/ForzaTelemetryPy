# __init__.py
# Paquete de interfaz gráfica para la telemetría